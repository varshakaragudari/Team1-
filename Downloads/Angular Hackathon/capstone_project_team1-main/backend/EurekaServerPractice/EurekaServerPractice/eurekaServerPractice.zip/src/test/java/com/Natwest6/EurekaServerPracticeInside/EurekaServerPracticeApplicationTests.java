package com.Natwest6.EurekaServerPracticeInside;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
